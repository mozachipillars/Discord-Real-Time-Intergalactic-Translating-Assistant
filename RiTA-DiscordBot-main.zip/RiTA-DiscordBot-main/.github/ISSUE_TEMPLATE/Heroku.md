---
name: Heroku
about: Copy the Build Log from Heroku
title: 'V: ID:'
labels: Heroku
assignees: ''

---

**Record Below Activity Feed > Build Log or Failed Version Reason**

Please Add label for Version to allow for investiation of build errors.
